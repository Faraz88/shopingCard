package com.altimetrik.ee.demo.repository;

import com.altimetrik.ee.demo.entity.ProductDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ProductDetailsRepository extends JpaRepository<ProductDetailsEntity, Long> {
    Optional<ProductDetailsEntity> findByProductName(String product);
}
