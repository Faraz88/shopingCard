package com.altimetrik.ee.demo.bean;

import lombok.Data;

@Data
public class UserCardDetailsBean {

    private Long userId;

    private String productName;

    private Long productPrice;

}
