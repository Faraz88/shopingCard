package com.altimetrik.ee.demo.dao;

import com.altimetrik.ee.demo.entity.UserCardDetailEntity;

import java.util.List;

public interface UserCardDaoService {

    void saveProductToCard(UserCardDetailEntity userCardDetailEntity);

    List<UserCardDetailEntity> getUserCardDetails(Long userId);
}
