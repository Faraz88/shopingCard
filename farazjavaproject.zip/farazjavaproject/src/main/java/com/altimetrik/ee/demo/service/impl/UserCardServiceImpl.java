package com.altimetrik.ee.demo.service.impl;

import com.altimetrik.ee.demo.bean.UserCardDetailResponse;
import com.altimetrik.ee.demo.bean.UserCardDetailsBean;
import com.altimetrik.ee.demo.dao.UserCardDaoService;
import com.altimetrik.ee.demo.entity.UserCardDetailEntity;
import com.altimetrik.ee.demo.service.UserCardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class UserCardServiceImpl implements UserCardService {

    @Autowired
    private UserCardDaoService userCardDaoService;

    @Override
    public void addProductToCard(UserCardDetailsBean userCardDetailsBean) {
        log.info("addProductToCard call with userCardDetailsBean {}", userCardDetailsBean);
        UserCardDetailEntity userCardDetailEntity = UserCardDetailEntity
                .builder()
                .userId(userCardDetailsBean.getUserId())
                .productName(userCardDetailsBean.getProductName())
                .productPrice(userCardDetailsBean.getProductPrice())
                .build();
        try {
            userCardDaoService.saveProductToCard(userCardDetailEntity);
        }catch (Exception ex){
            log.error("Exception occurred while adding product to card exception is {}", ex);
        }
    }

    @Override
    public Set<UserCardDetailResponse> getUserCardDetails(Long userId) {
        log.info("getUserCardDetails call with userId {}", userId);
        List<UserCardDetailEntity> userCardDetailEntities = userCardDaoService.getUserCardDetails(userId);
        List<UserCardDetailResponse> userCardDetailResponseArrayList = new ArrayList<>();
        if (userCardDetailEntities != null) {
            userCardDetailEntities.forEach(userCardDetailEntity -> {
                userCardDetailResponseArrayList.add(mapEntityToBean(userCardDetailEntity));
            });
        }
        userCardDetailResponseArrayList.sort(Comparator.comparing(UserCardDetailResponse::getProductPrice));
        Set<UserCardDetailResponse> distinctList;
        distinctList = new LinkedHashSet<>(userCardDetailResponseArrayList);
        return distinctList;
    }

    private UserCardDetailResponse mapEntityToBean(UserCardDetailEntity userCardDetailEntity) {
        UserCardDetailResponse userCardDetailResponse = new UserCardDetailResponse();
        userCardDetailResponse.setProductName(userCardDetailEntity.getProductName());
        userCardDetailResponse.setProductPrice(userCardDetailEntity.getProductPrice());
        return userCardDetailResponse;
    }
}
