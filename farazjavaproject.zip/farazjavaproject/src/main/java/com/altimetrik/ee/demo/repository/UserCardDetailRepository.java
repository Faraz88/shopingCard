package com.altimetrik.ee.demo.repository;

import com.altimetrik.ee.demo.entity.UserCardDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserCardDetailRepository extends JpaRepository<UserCardDetailEntity, Long> {
    List<UserCardDetailEntity> findAllByUserId(Long userId);
}
