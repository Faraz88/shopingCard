package com.altimetrik.ee.demo.service.impl;

import com.altimetrik.ee.demo.bean.ProductDetailsBean;
import com.altimetrik.ee.demo.dao.ProductDaoService;
import com.altimetrik.ee.demo.entity.ProductDetailsEntity;
import com.altimetrik.ee.demo.service.ProductDetailsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class ProductDetailsServiceImpl implements ProductDetailsService {


    @Autowired
    private ProductDaoService productDaoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public String addNewProduct(ProductDetailsBean productDetailsBean) {
        log.info("addNewProduct call with productDetailsBean {}", productDetailsBean);
        ProductDetailsEntity productDetailsEntity = ProductDetailsEntity
                .builder()
                .productName(productDetailsBean.getProduct())
                .productPrice(productDetailsBean.getPrice())
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        try{
            productDaoService.saveProduct(productDetailsEntity);
            return "Product successfully added";
        }catch (Exception ex){
            log.error("Exception occurred while saving product for product {} and exception {}", productDetailsBean.getProduct(), ex);
            return "Product not added";
        }
    }

    @Override
    public String updateProduct(ProductDetailsBean productDetailsBean) {
        Optional<ProductDetailsEntity> productDetailsEntity = productDaoService.getByName(productDetailsBean.getProduct());
        if (productDetailsEntity != null && productDetailsEntity.isPresent()){
            productDetailsEntity.get().setProductPrice(productDetailsBean.getPrice());
            productDetailsEntity.get().setUpdatedAt(LocalDateTime.now());
            productDaoService.saveProduct(productDetailsEntity.get());
            return "Product updated successfully";
        }else {
            return "Product not found";
        }
    }

    @Override
    public List<ProductDetailsBean> getAllProduct() {
        List<ProductDetailsEntity> productDetailsEntityList = productDaoService.getAllProduct();
        List<ProductDetailsBean> productDetailsBeanList = new ArrayList<>();
        productDetailsEntityList.forEach(product -> {
            productDetailsBeanList.add(mapEntityToBean(product));
        });
        return productDetailsBeanList;
    }

    private ProductDetailsBean mapEntityToBean(ProductDetailsEntity product) {
        ProductDetailsBean productDetailsBean = new ProductDetailsBean();
        productDetailsBean.setProduct(product.getProductName());
        productDetailsBean.setPrice(product.getProductPrice());
        return productDetailsBean;
    }
}
