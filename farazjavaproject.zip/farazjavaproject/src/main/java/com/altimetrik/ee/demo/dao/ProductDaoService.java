package com.altimetrik.ee.demo.dao;

import com.altimetrik.ee.demo.entity.ProductDetailsEntity;

import java.util.List;
import java.util.Optional;

public interface ProductDaoService {

    ProductDetailsEntity saveProduct(ProductDetailsEntity productDetailsEntity);

    List<ProductDetailsEntity> getAllProduct();

    Optional<ProductDetailsEntity> getByName(String product);
}
