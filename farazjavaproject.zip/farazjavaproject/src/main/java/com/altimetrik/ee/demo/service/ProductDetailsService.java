package com.altimetrik.ee.demo.service;

import com.altimetrik.ee.demo.bean.ProductDetailsBean;

import java.util.List;

public interface ProductDetailsService {

    String addNewProduct(ProductDetailsBean productDetailsBean);

    String updateProduct(ProductDetailsBean productDetailsBean);

    List<ProductDetailsBean> getAllProduct();
}
