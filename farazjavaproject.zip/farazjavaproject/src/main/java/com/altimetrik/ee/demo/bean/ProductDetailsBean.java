package com.altimetrik.ee.demo.bean;

import lombok.Data;

@Data
public class ProductDetailsBean {

    private String product;

    private Long price;
}
