package com.altimetrik.ee.demo.controller;

import com.altimetrik.ee.demo.bean.ProductDetailsBean;
import com.altimetrik.ee.demo.service.ProductDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1")
public class BrowserCatalogueController {

    @Autowired
    private ProductDetailsService productDetailsService;

    @PostMapping("/add/product")
    public ResponseEntity<String> addProduct(@RequestBody ProductDetailsBean productDetailsBean){
        return ResponseEntity.ok(productDetailsService.addNewProduct(productDetailsBean));
    }

    @PutMapping("/update/product")
    public ResponseEntity<String> updateProduct(@RequestBody ProductDetailsBean productDetailsBean){
        return ResponseEntity.ok(productDetailsService.updateProduct(productDetailsBean));
    }

    @GetMapping("/all/product")
    public ResponseEntity<List<ProductDetailsBean>> getAllProduct(){
        return ResponseEntity.ok(productDetailsService.getAllProduct());
    }
}
