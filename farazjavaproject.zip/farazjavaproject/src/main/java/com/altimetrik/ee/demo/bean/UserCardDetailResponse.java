package com.altimetrik.ee.demo.bean;

import lombok.Data;

@Data
public class UserCardDetailResponse {

    private String productName;

    private Long productPrice;
}
