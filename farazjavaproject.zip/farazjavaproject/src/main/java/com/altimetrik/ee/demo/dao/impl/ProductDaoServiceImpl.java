package com.altimetrik.ee.demo.dao.impl;

import com.altimetrik.ee.demo.dao.ProductDaoService;
import com.altimetrik.ee.demo.entity.ProductDetailsEntity;
import com.altimetrik.ee.demo.repository.ProductDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductDaoServiceImpl implements ProductDaoService {

    @Autowired
    private ProductDetailsRepository productDetailsRepository;


    @Override
    public ProductDetailsEntity saveProduct(ProductDetailsEntity productDetailsEntity) {
        return productDetailsRepository.save(productDetailsEntity);
    }

    @Override
    public List<ProductDetailsEntity> getAllProduct() {
        return productDetailsRepository.findAll();
    }

    @Override
    public Optional<ProductDetailsEntity> getByName(String product) {
        return productDetailsRepository.findByProductName(product);
    }
}
