package com.altimetrik.ee.demo.controller;


import com.altimetrik.ee.demo.bean.UserCardDetailResponse;
import com.altimetrik.ee.demo.bean.UserCardDetailsBean;
import com.altimetrik.ee.demo.service.UserCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping(value = "/api/v1")
public class UserCardController {

    @Autowired
    private UserCardService userCardService;

    @PostMapping("/add/product/card")
    public void addProduct(@RequestBody UserCardDetailsBean userCardDetailsBean){
        userCardService.addProductToCard(userCardDetailsBean);
    }

    @GetMapping("/card/detail/{userId}")
    public ResponseEntity<Set<UserCardDetailResponse>> getAllProduct(@PathVariable(name = "userId") Long userId){
        return ResponseEntity.ok(userCardService.getUserCardDetails(userId));
    }
}
