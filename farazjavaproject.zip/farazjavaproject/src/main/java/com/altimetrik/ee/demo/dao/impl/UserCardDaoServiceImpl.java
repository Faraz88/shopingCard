package com.altimetrik.ee.demo.dao.impl;

import com.altimetrik.ee.demo.dao.UserCardDaoService;
import com.altimetrik.ee.demo.entity.UserCardDetailEntity;
import com.altimetrik.ee.demo.repository.UserCardDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserCardDaoServiceImpl implements UserCardDaoService {

    @Autowired
    private UserCardDetailRepository userCardDetailRepository;

    @Override
    public void saveProductToCard(UserCardDetailEntity userCardDetailEntity) {
        userCardDetailRepository.save(userCardDetailEntity);
    }

    @Override
    public List<UserCardDetailEntity> getUserCardDetails(Long userId) {
        return userCardDetailRepository.findAllByUserId(userId);
    }
}
