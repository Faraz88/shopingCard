package com.altimetrik.ee.demo.service;

import com.altimetrik.ee.demo.bean.UserCardDetailResponse;
import com.altimetrik.ee.demo.bean.UserCardDetailsBean;

import java.util.List;
import java.util.Set;

public interface UserCardService {

    void addProductToCard(UserCardDetailsBean userCardDetailsBean);

    Set<UserCardDetailResponse> getUserCardDetails(Long userId);
}
